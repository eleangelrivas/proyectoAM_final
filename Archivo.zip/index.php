<?php 
	header('Location: logica_negocio/ingreso/index.php');
?>