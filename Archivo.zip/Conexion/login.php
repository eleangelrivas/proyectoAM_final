<?php 
	define('DATABASE','telares');
	define('HOSTNAME','localhost');
	define('USERNAME','ele1990');
	define('PASSWORD','Root1234.');
?>