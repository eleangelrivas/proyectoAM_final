<?php 
	
	define("HOME", $_SERVER['HTTP_HOST'].'/proyectoAM_final');


?>
  