<footer class="footer">
         © <?php echo date("Y",strtotime("-1 year")); ?> - <?php echo date("Y"); ?> UES-FMP <span class="text-muted d-none d-sm-inline-block float-right">Curso de PHP</span>
</footer>