
        <script src="../../public/assets/js/jquery.min.js"></script>
        <script src="../../public/assets/js/bootstrap.bundle.min.js"></script>
        <script src="../../public/assets/js/modernizr.min.js"></script>
        <script src="../../public/assets/js/jquery.slimscroll.js"></script>
        <script src="../../public/assets/js/waves.js"></script>
        <script src="../../public/assets/js/jquery.nicescroll.js"></script>
        <script src="../../public/assets/js/jquery.scrollTo.min.js"></script>
        <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
        <script src="../../public/plugins/bootstrap-filestyle/js/bootstrap-filestyle.min.js"></script>

        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.maskedinput/1.4.1/jquery.maskedinput.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.maskedinput/1.4.1/jquery.maskedinput.js"></script>
        <script type="text/javascript" src="../../public/plugins/parsleyjs/parsley.min.js"></script>