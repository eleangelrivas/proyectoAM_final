   <!-- ========== Left Sidebar Start ========== -->
   <div class="left side-menu">

<!-- LOGO -->
<div class="topbar-left">
    <div class="">
        <!--<a href="index.php" class="logo text-center">Admiria</a>-->
        <a href="index.php" class="logo"><img src="../../public/assets/images/logo-sm.png" height="36" alt="logo"></a>
    </div>
</div>

<div class="sidebar-inner slimscrollleft">
    <div id="sidebar-menu">
        <ul>
            <li class="menu-title">Main</li>

            <li>
                <a href="../home/?modulo=HOME" class="waves-effect"><i class="mdi mdi-home"></i><span> Home </span></a>
            </li>

            

            <li class="has_sub">
                <a href="javascript:void(0);" class="waves-effect"><i class="mdi mdi-cube-outline"></i><span> Productos <span class="pull-right"><i class="mdi mdi-chevron-right"></i></span> </span></a>
                <ul class="list-unstyled">
                    <li><a href="email-inbox.php">Nuevo Producto</a></li>
                    <li><a href="email-read.php">Administrar Producto</a></li>
                    
                </ul>
            </li>

             <li class="has_sub">
                <a href="javascript:void(0);" class="waves-effect"><i class="mdi mdi-account-location"></i><span> Productores <span class="pull-right"><i class="mdi mdi-chevron-right"></i></span> </span></a>
                <ul class="list-unstyled">
                    <li><a href="email-inbox.php">Nuevo Productor</a></li>
                    <li><a href="email-read.php">Produccion</a></li>
                    
                </ul>
            </li>


            <li>
                <a href="../usuarios/?modulo=USUARIOS" class="waves-effect"><i class="mdi mdi-cube-outline"></i><span> Usuarios </span></a>
            </li>

             

        </ul>
    </div>
    <div class="clearfix"></div>
</div> <!-- end sidebarinner -->
</div>
<!-- Left Sidebar End -->
